/*
 * Copyright 2008 Tumri Inc.
 *
 * Utility functions for Tumri Analytics UI.
 *
 */

function submitFormWithDeleteAction(formId, action,message) {

	var x=window.confirm(message)
	if (x){
		document.forms[formId].action = action;
    	document.forms[formId].submit();
	}
}

function submitFormWithAction(formId, action) {
    document.forms[formId].action = action;
    document.forms[formId].submit();
}

function submitForm(formId) {
    document.forms[formId].submit();
}

function submitFormOnEnter(formId, e) {
    var keycode;
    if (window.event) {
        keycode = window.event.keyCode;
    }
    else if (e) {
        keycode = e.which;
    }
    else {
        return true;
    }
    if (keycode == 13) {
        document.forms[formId].submit();
        return false;
    }
    else {
        return true;
    }
}

function setElementValue(formName, elementName, val)
{
    document.forms[formName].elements[elementName].value = val;
}

