-- This script should be run once per database installation for creating the application users in DB.

create database if not exists TM_SYSTEM_DB;
create user TMUSER identified by 'w3lc0m31';
create user HC_USER identified by 'w3lc0m31';


grant SELECT on TM_SYSTEM_DB.* TO HC_USER identified by 'w3lc0m31';
grant SELECT on TM_SYSTEM_DB.* TO HC_USER@'localhost'  identified by 'w3lc0m31';


grant all on TM_SYSTEM_DB.* TO TMUSER identified by 'w3lc0m31';
grant all on TM_SYSTEM_DB.* TO TMUSER@'localhost' identified by 'w3lc0m31';


GRANT SELECT ON mysql.* TO TMUSER identified by 'w3lc0m31';
GRANT SELECT ON mysql.* TO TMUSER@'localhost' identified by 'w3lc0m31';



grant all on TM_SYSTEM_DB.* TO CPUSER identified by 'w3lc0m31';
grant all on TM_SYSTEM_DB.* TO CPUSER@'localhost' identified by 'w3lc0m31';